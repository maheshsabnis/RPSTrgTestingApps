namespace MVC_WebApp.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Product
    {
        [Key]
        public int ProductRowId { get; set; }

        [Required]
        public string ProductId { get; set; }

        [Required]
        public string ProductName { get; set; }

        [Required]
        public string Manufacturer { get; set; }

        public int Price { get; set; }

        public int CategoryRowId { get; set; }

        public virtual Category Category { get; set; }
    }
}
