﻿using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_WebApp.Controllers
{
    public class CategoryNewController : Controller
    {

        CategoryNewRepository catRepo;

        public CategoryNewController()
        {
            catRepo = new CategoryNewRepository(); 
        }


        // GET: CategoryNew
        public ActionResult Index()
        {
            var cats = catRepo.GetCats();
            return View("Index", cats);
        }

        public ActionResult Create()
        {
            var cat = new Category();
            return View(cat);
        }
        [HttpPost]
        public ActionResult Create(Category category)
        {
            if (ModelState.IsValid)
            {
                catRepo.CreateCat(category);
                return RedirectToAction("Index");
            }
            return View("Error");
        }

    }
}