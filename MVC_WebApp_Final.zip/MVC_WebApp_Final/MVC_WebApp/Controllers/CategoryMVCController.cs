﻿using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_WebApp.Controllers
{
    public class CategoryMVCController : Controller
    {
        private readonly IRepository<Category, int> repository;

        /// <summary>
        /// Inject the repository
        /// </summary>
        public CategoryMVCController(IRepository<Category,int> catRepo)
        {
            repository = catRepo;
        }

        // GET: CategoryMVC
        public ActionResult Index()
        {
            var cats = repository.Get();
            return View("Index",cats);
        }


    }
}