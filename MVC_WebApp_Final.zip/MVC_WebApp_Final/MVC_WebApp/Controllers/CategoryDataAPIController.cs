﻿using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MVC_WebApp.Controllers
{
    public class CategoryDataAPIController : ApiController
    {
        private readonly IRepository<Category, int> repository;
        public CategoryDataAPIController(IRepository<Category, int> repository)
        {
            this.repository = repository;
        }

        public IHttpActionResult Get()
        {
            var cats = repository.Get();

            var result = (from c in cats
                         select new Category()
                         {
                              CategoryRowId  =c.CategoryRowId,
                              CategoryId = c.CategoryId,
                              CategoryName = c.CategoryName,
                              BasePrice = c.BasePrice
                         }).ToList<Category>();

            return Ok(result);
        }

        public IHttpActionResult Post(Category category)
        {
            if (ModelState.IsValid)
            {
                category = repository.Create(category);
                return Ok(category);
            }
            return BadRequest(ModelState);
        }

    }
}
