﻿  
using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.Mvc;

namespace MVC_WebApp.Controllers
{
    public class CategoryController : Controller
    {
        private readonly IRepository<Category, int> catRepo;

        public CategoryController(IRepository<Category, int> catRepo)
        {
            this.catRepo = catRepo;
        }

        // GET: Category
        public ActionResult Index()
        {
            var cats = catRepo.Get();
            return View(cats);
        }


        public ActionResult Create()
        {
            var cat = new Category();
            return View(cat);
        }

        [HttpPost]
        public ActionResult Create(Category cat)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (cat.BasePrice < 0)
                        throw new Exception("Base Price can not be -ve");
                    cat = catRepo.Create(cat);
                    return RedirectToAction("Index");
                }
                return View(cat);
            }
            catch (Exception ex)
            {
                throw ex;
                //ErrorModel error = new ErrorModel();

                //error.ControllerName = this.RouteData.Values["controller"].ToString();
                //error.ActionName = this.RouteData.Values["action"].ToString();
                //error.ErrorMessage = ex.Message;
                //return View("Error",error);
            }
        }

        public ActionResult Edit(int id)
        {
            var cat = catRepo.Get(id);
            return View(cat);
        }

        [HttpPost]
        public ActionResult Edit(int id,Category cat)
        {
            if (ModelState.IsValid)
            {
                var res = catRepo.Update(id,cat);
                if (res)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            return View(cat);
        }

        public ActionResult Delete(int id)
        {
            var cat = catRepo.Delete(id);
            return RedirectToAction("Index");
        }
    }
}