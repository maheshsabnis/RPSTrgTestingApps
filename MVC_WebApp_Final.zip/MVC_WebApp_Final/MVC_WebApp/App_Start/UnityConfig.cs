using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using MVC_WebApp.Services;
using System.Web.Http;
using System.Web.Mvc;
using Unity;
using Unity.WebApi;

namespace MVC_WebApp
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // easily mocked
            container.RegisterType<IRepository<Category, int>, CategoryRepository>();
            container.RegisterType<IRepository<Product, int>, ProductRepository>();

            DependencyResolver.SetResolver(new Unity.Mvc5.UnityDependencyResolver(container));
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}