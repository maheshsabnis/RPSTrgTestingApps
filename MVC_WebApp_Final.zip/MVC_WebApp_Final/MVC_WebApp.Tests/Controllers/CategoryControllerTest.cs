﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using MVC_WebApp.Controllers;
using MVC_WebApp.Models;
using MVC_WebApp.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace MVC_WebApp.Tests.Controllers
{
    [TestClass]
    public class CategoryControllerTest
    {
        [TestMethod]
        public void Index_Returning_ViewResult_Category_List()
        {
            // arrange 
            var mockRepo = new Mock<IRepository<Category, int>>();
            // defining the mock type
            mockRepo.Setup(repo => repo.Get()).Returns(GetTestCategories());
            // creating controller instance
            var controller = new CategoryController(mockRepo.Object);

            // act
            // call the index method
            var result = controller.Index() as ViewResult;
           
            // assert
            Assert.IsInstanceOfType(result, typeof(ViewResult));
          
           Assert.IsInstanceOfType(result.ViewData.Model, typeof(List<Category>));
         
        }

        private IEnumerable<Category> GetTestCategories()
        {
            return new List<Category>()
            {
                new Category(){CategoryRowId=1, CategoryId="Cat0001",CategoryName="Electronics",BasePrice=12000 },
                new Category(){CategoryRowId=2, CategoryId="Cat0002",CategoryName="Electrical",BasePrice=20 }
            };
        }

        [TestMethod]
        public void Create_Returning_Thows_Exception()
        {
            // arrange 
            var mockRepo = new Mock<IRepository<Category, int>>();
            // arrange data
            Category cat = new Category()
            {
                 CategoryId = "Cat0987",
                 CategoryName = "IT",
                 BasePrice = -8864
            };

            // creating controller instance
            var controller = new CategoryController(mockRepo.Object);

            // act
            var ex = Assert.ThrowsException<Exception>(() =>
            {
                // call the index method
                var result = controller.Create(cat);
            });
            Assert.AreEqual("Base Price can not be -ve", ex.Message);
        }
    }
}
