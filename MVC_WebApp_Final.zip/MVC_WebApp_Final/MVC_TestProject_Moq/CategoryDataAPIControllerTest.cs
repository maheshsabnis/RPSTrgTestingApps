﻿using System;
using System.Web.Http.Results;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using MVC_WebApp.Controllers;
using MVC_WebApp.Models;
using MVC_WebApp.Repositories;

namespace MVC_TestProject_Moq
{
    [TestClass]
    public class CategoryDataAPIControllerTest
    {
        [TestMethod]
        public void Post_Method_Return_BadResult_For_ModelState()
        {
            var mockRepo = new Mock<IRepository<Category, int>>();
            var controller = new CategoryDataAPIController(mockRepo.Object);

            // define the rules for the model state
            controller.ModelState.AddModelError("CategoryName", "Required");

            // defining the Test Data
            var cat = new Category()
            {
                 CategoryId = "Cat506",
                 BasePrice  =3000
            };
            // install System.Web.Http
            var methodResult = controller.Post(cat);

            // Assertion for the result with Bad request
            Assert.IsInstanceOfType(methodResult,
                typeof(InvalidModelStateResult));
        }


        [TestMethod]
        public void Post_Method_Return_OK()
        {
            var mockRepo = new Mock<IRepository<Category, int>>();
            var controller = new CategoryDataAPIController(mockRepo.Object);


            // defining the Test Data
            var cat = new Category()
            {
                CategoryId = "Cat506",
                CategoryName = "testCase",
                BasePrice = 3000
            };
            // install System.Web.Http
            var methodResult = controller.Post(cat);

            // Assertion for the result with Bad request
            Assert.IsInstanceOfType(methodResult,
                typeof(OkNegotiatedContentResult<Category>));
        }
    }
}
