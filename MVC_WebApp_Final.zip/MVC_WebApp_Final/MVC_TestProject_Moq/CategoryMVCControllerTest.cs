﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using MVC_WebApp.Controllers;
using MVC_WebApp.Models;
using MVC_WebApp.Repositories;

namespace MVC_TestProject_Moq
{
    [TestClass]
    public class CategoryMVCControllerTest
    {
        [TestMethod]
        public void Index_Moq_Test()
        {
            // arrange the Mock Object based on repository interface
            // and set up the test data
            // Use the Mock<T>, here T is a type for Fake 
            // object creation in a memory
            // FakeObject is furtjer used for managing the 
            // Fake Data aka proxy data aka the In-Memoery 
            // data stores
            var mockRepo = new Mock<IRepository<Category,int>>();
            // define the setup for Mock with Fake data
            // setupe method will generate the in-memory
            // implementation for the method with the return data
            mockRepo.Setup(repo => repo.Get())
                    .Returns(GetCategories());
            // instance of the controller
            // by passing the Fake Object Dependency to it
            // this will avoid use of Depednency Injection
            // from Unity Container
            var controller = new CategoryMVCController(mockRepo.Object);

            // act
            var result = controller.Index() as ViewResult;

            // assertion
            Assert.IsInstanceOfType(result, typeof(ViewResult));
            Assert.AreEqual(result.ViewName, "Index");
            Assert.IsInstanceOfType(result.Model, typeof(List<Category>));
           
        }
        private IEnumerable<Category> GetCategories()
        {
            return new List<Category>()
            {
                new Category() {CategoryRowId=1,
                    CategoryId="C1",
                    CategoryName="Cat1",
                    BasePrice=1000 },
                new Category() {CategoryRowId=2,
                    CategoryId="C2",
                    CategoryName="Cat2",
                    BasePrice=2000 }
            };

        }
    }
}
