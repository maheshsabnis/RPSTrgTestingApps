﻿using System;
using System.CodeDom;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using MVC_WebApp.Models;
using MVC_WebApp.Repositories;

namespace MVC_New_TestProject
{
    [TestClass]
    public class CategoryRepositoryModelTest
    {
        [TestMethod]
        public void ChekCatExistTest()
        {
            var db = new CategoryNewRepository();

            var res = db.CheckCatExists(10);

            Assert.IsTrue(res);
        }

        [TestMethod]
        public void GetCateTest()
        {
            int id = 1;
            var db = new CategoryNewRepository();
            var res = db.GetCat(id);
            Assert.IsInstanceOfType(res, typeof(Category));
        }

        [TestMethod]
        public void GetCateReturnNullTest()
        {
            int id = 10;
            var db = new CategoryNewRepository();
            var res = db.GetCat(id);
            Assert.IsNull(res);
        }

        [TestMethod]
        public void GetCateThrowsExceptionTest()
        {
            var db = new CategoryNewRepository();
            int id = -1;
            var exception = Assert.ThrowsException<Exception>(()=> { 
                var res = db.GetCat(id);
            });
            Assert.AreEqual("id cannot be 0 or negative", exception.Message);
        }



        [TestMethod]
        public void ChekCatExistMockTest()
        {
            // create aFake object

            var fakeObject = new Mock<ICatDataAcess>();

            // define a setup to access the method from the
            // mock object aka Mock Configuration
            // with the test data
            fakeObject.Setup(cat => 
            cat.CheckCatExists(It.IsAny<int>()))
                .Returns(false);

            // call the method

            var res = fakeObject.Object.CheckCatExists(10);

            Assert.IsTrue(res);
        }


    }
}
